package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class LoginController {
	// Pantalla principal en la que se a�ade o quita contenido
	private BorderPane rootLayout;

	@FXML
	private TextField txtUser;

	@FXML
	private void initialize() {

	}

	@FXML
	public void Ingresar(ActionEvent event) throws IOException {

		// Cargo la vista
		try {
			Node source = (Node) event.getSource();
			Stage stage = (Stage) source.getScene().getWindow();
			// Cargamos el ARCHIVO
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MenuController.class.getResource("/view/MenuPantalla.fxml"));
			rootLayout = (BorderPane) loader.load();
			stage.setTitle("Menu");
			MenuController menuCon = loader.getController();
			menuCon.setRoot1(rootLayout);
			Scene scene = new Scene(rootLayout);
			stage.setScene(scene);
			stage.show();
			// Se sit�a en el centro del dise�o principal

		} catch (IOException e) {
			e.printStackTrace();
		}

//		// Cargo la vista
//		try {
//			// Cargamos el ARCHIVO
//			FXMLLoader loader = new FXMLLoader();
//			// Cargamos el ARCHIVO
//			Parent home =FXMLLoader.load(getClass().getResource("/view/MenuPantalla.fxml"));
//			Scene homeScene = new Scene(home);
//			Stage appstage=(Stage)((Node) event.getSource()).getScene().getWindow();
//			appstage.setScene(homeScene);
//			
//			
//			MenuController menuCon = loader.getController();
//			menuCon.setRoot1(rootLayout);
//			
//			
//			appstage.setTitle("Menu");
//			
//	
//			
//		
//			appstage.show();
//			// Se sit�a en el centro del dise�o principal

	}

	public BorderPane getRootLayout() {
		return rootLayout;
	}

	public void setRootLayout(BorderPane rootLayout) {
		this.rootLayout = rootLayout;
	}

}